describe('Controllers', function(){
    var scope;

    // load the controller's module
    beforeEach(module('kontribute.controllers'));

    beforeEach(inject(function($rootScope, $controller) {
        scope = $rootScope.$new();
        $controller('showGuests', {$scope: scope});
        // $controller('locationClick', {$scope: scope});
    }));

    // tests start here
    it('guestButtonClicked should be true', function(){
        var guestButtonClicked = false;
        expect(scope.guestButtonClicked).toEqual(true);
    });

    // it('locationSelected should be true', function(){
    //     var locationSelected = false;
    //     expect(scope.locationSelected).toEqual(true);
    // });
});